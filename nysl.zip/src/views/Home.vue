<template>
  <div>
 
 <Titulo title="Home" />
   <div class="car">
     <b-carousel controls indicators img-width="100vw" img-height="70%" style="text-shadow: 1px 1px 2px #333;">
        <b-carousel-slide
          caption="August 4"
          text="NYSL Fundraiser"
          img-src='https://upload.wikimedia.org/wikipedia/commons/9/92/Youth-soccer-indiana.jpg'
        ></b-carousel-slide>
        <b-carousel-slide
          caption="August 16"
          text="Season Kick-off: Meet the Teams"
          img-src='https://i.ytimg.com/vi/20R_mNk8K4Y/maxresdefault.jpg'
        ></b-carousel-slide>
        <b-carousel-slide
          caption="September 1"
          text="First Game of the Season"
          img-src="https://cdn.cnn.com/cnnnext/dam/assets/160120192256-kids-sports-stock-super-tease.jpg"
        ></b-carousel-slide>
      </b-carousel>
 
</div>

  </div>
</template>

<script>
import  Titulo from "../components/Titulo.vue"
export default {
    
components:{
    Titulo
}}
</script>
<style lang="scss" scoped>


</style>
