<template>
  <div id="app" >
 <div class="header">
    <router-link to="/">
   <div>
  <img class="logo d-none d-md-inline"  src="./assets/nysl_logo.png" alt="nysl_logo" >
   <h1>Northside Soccer League</h1></div>
     </router-link>
 </div>

    <Sidebar />
   
  </div>
</template>

<script>
  import Sidebar from './components/Sidebar.vue'
  export default {
    components: {
      Sidebar
    }
  }
  
</script>

<style lang="scss">

  @import url('https://fonts.googleapis.com/css?family=Anton');
  @import url('https://use.fontawesome.com/releases/v5.8.2/css/all.css');
  body {
    margin: 0;
    padding: 0;
    
  }
  
  #app {
    font-family: 'Anton', Arial, Helvetica, sans-serif;
    font-size: 1rem;
    letter-spacing: 1px;
    color: #322F42;
    width: 100%;
    max-height:100vh;
    
  }
  .header{
    width:100vw;
    height: 9vh;
    background-color:rgb(10, 10, 10);
    display:flex;
    align-items:center;
    justify-content: flex-end;
   div{
     width:auto;
     display:flex;
     flex-direction:row;
     margin-right: 2em;
     align-items: center;
     h1{ font-size:20px ;
       color:whitesmoke
   }
   
   }

  }
  .logo{
     width:35px;
     height:35px;
     margin-right:1.5em;
   }
</style>