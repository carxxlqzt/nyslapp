<template>
  <div >
     <Titulo title="Schedule" />
     <div class="main">
      
       <div class="month"> <h1> {{locations.month1}} </h1></div>
       <p> *Check the matches that will compete through the date </p>
       <div v-for="(e,index) in locations.september.dates" :key="index" class="cont">
         <!-- <b-button v-b-toggle="index+'collapse'" class="m-1">{{e.date}}</b-button> -->

       <button v-b-modal="index+'my'" class="dates">
         <p>{{e.date}}</p>
        
       </button>
      
       </div>
       <div v-for="(e,index) in locations.september.dates" :key="index">
         <b-modal :id="index+'my'" title="TEAMS"> 
           <h2>{{e.teams1.teams}}</h2>
           Location: {{e.teams1.location}} <br> Time: {{e.teams1.times}} <br>
           <h2> {{e.teams2.teams}}</h2>
           Location: {{e.teams2.location}} <br> Time: {{e.teams2.times}}
           
            </b-modal> </div>
  <div class="cont">
    <button v-b-modal="'modal5'" class="dates">
         <p>9/29</p>
        
       </button>
      
  </div>
  <div   >
         <b-modal id="modal5" title="TEAM"> 
           <h2>U4 and U5</h2>
           Location: Greenbay <br> Time: 9:30 a.m<br>
           
            </b-modal> </div>
 
         
  <div class="month"> <h1> {{locations.month2}} </h1></div>
       <div  v-for="(e,index) in locations.october.dates" :key="index" class="cont">
         <button v-b-modal="index+'modal'" class="dates">
         <p>{{e.date}}</p>
        
       </button>
       <!-- <div class="dates">
         <p>{{e.date}}</p>
       </div>
        <More :team1="e.teams1.teams" :team2="e.teams2.teams" :location1="e.teams1.location"
        :location2="e.teams2.location" :time1="e.teams1.times" :time2="e.teams2.times" />
       </div> -->
     
     </div>
     <div v-for="(e,index) in locations.october.dates" :key="index">
         <b-modal :id="index+'modal'" title="TEAMS">
            <h2>{{e.teams1.teams}}</h2>
           Location: {{e.teams1.location}} <br> Time: {{e.teams1.times}} <br>
           <h2> {{e.teams2.teams}}</h2>
           Location: {{e.teams2.location}} <br> Time: {{e.teams2.times}}
           
            </b-modal> 
            </div>
     </div>
  </div>
</template>
<script>

import{mapState} from "vuex"
import  Titulo from "../components/Titulo.vue"
// import More from "../components/More.vue"
export default {
 data:function(){
        return{
           ok:false
        }
    },
  computed:{
    ...mapState(["locations"])
  },
components:{
    Titulo,
    // More
},
methods:{
 
}
}
</script>
<style lang="scss" scoped>
  .main{
   width:100vw;
   display:flex;
   flex-direction: column;
   align-items: center;
   p{
     margin-top:.5em;
   }
  }
  .month{
    background-color:rgba(172, 255, 47, 0.486);
    width:100%;
    height:auto;
    display: flex;
    justify-content: center;
    margin-top:2%;
    
  }
  .cont{
    width:80vw;
    display:flex;
    flex-direction:row;
    flex-wrap: wrap;
    margin-top:2%;

  

  }
  .dates{
    width:50%;
    // margin:1px;
    display:flex;
    background-color:rgba(28, 114, 253, 0.472);
    flex-direction: row;
    flex-grow:2;
    justify-content:center;
    align-items: center;
    border-radius:20px;
    // padding:1em;
    p{
      width:auto;
      margin:0;
      padding: 5px;
      color:white;
      font-size:24px;
      text-shadow: 5px 5px 5px black;
    }
  }
  .datesL{
     display:flex;
    //  margin:1px;
    background-color:grey;
    flex-grow:3 ;
    justify-content:center;
    align-items: center;
    // padding:1em;
    color:white;
    border-radius:20px;


    p{
      width:auto;
      padding: 5px;

      margin:0;
      font-size:24px;
  text-shadow: 5px 5px 5px black;
    }
  }

</style>